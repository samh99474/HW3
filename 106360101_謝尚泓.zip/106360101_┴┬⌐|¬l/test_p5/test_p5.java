package test_p5;

public class test_p5 {
	
	public static void main(String[] args)
	{	
	Car car1;
	car1 = new Car();
	}
}
class Car{
	//���O
}